# Custom Conky Configuration

A highly customized Conky system monitor with circular gauges and real-time system metrics.

## Features

### Time Display
- **Outer Ring**: Seconds (Blue)
- **Middle Ring**: Minutes (Cyan)
- **Inner Ring**: Hours (Light Blue)

### System Monitoring
- **CPU Usage Ring** (Orange)
  - Tracks CPU0 usage percentage
  - Outer ring with 45px radius
  - Semi-transparent background with solid indicator

- **RAM Usage Ring** (Deep Sky Blue)
  - Tracks total memory usage percentage
  - Inner ring with 30px radius
  - Positioned concentrically with CPU ring

### Network Monitoring
- **Upload Speed Ring** (Green)
  - Tracks upload speed on eth0
  - Outer ring with 25px radius
  - Positioned at bottom of display (x=133, y=720)
  - Max speed: 500 Mbps

- **Download Speed Ring** (Red)
  - Tracks download speed on eth0
  - Inner ring with 15px radius
  - Positioned concentrically with upload ring
  - Max speed: 500 Mbps

## Technical Details

### Files
- `conky.conf`: Main configuration file
- `rings.lua`: Lua script for circular gauges and visual elements

### Dependencies
- Conky (v1.10+)
- Lua (for custom scripts)
- Conky-Lua bindings

### Installation
1. Copy the `poku` directory to `~/.config/conky/Aureola/`
2. Make sure Conky is installed and configured to use Lua
3. Run with: `conky -c ~/.config/conky/Aureola/poku/conky.conf`

### Autostart (XFCE)
To start Conky automatically on login:
1. Create a desktop entry in `~/.config/autostart/conky.desktop`
2. Set it to execute the Conky command with the config file

## Customization

### Ring Gauges
All rings are defined in `rings.lua` with the following parameters:
- `name`: The Conky variable to monitor
- `arg`: Arguments for the variable
- `max`: Maximum value for 100% fill
- `bg_colour`/`bg_alpha`: Background color and transparency
- `fg_colour`/`fg_alpha`: Foreground color and transparency
- `x`/`y`: Position coordinates
- `radius`: Size of the ring
- `thickness`: Line thickness
- `start_angle`/`end_angle`: Arc angles (0-360 for full circle)

### Colors
- Time: Various shades of blue
- CPU: Orange (#FFA500)
- RAM: Deep Sky Blue (#00BFFF)
- Network Up: Green (#00FF00)
- Network Down: Red (#FF0000)

## Troubleshooting
- If rings don't appear, check that all Lua dependencies are installed
- Ensure the network interface in the config matches your system (currently set to `eth0`)
- Adjust the `maximum_width` and `minimum_height` in `conky.conf` if elements are cut off

## License
This configuration is free to use and modify under the MIT License.
